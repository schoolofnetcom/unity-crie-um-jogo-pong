﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

	Rigidbody2D rb;
	[SerializeField]float velocidadeY = 150f;
	[SerializeField]int playerID;
	void Start () {
		rb = GetComponent<Rigidbody2D> ();
	}
	

	void Update () {
		Movimento (playerID);
	}

	void Movimento(int jogador){
		if (jogador == 1) {
			if (Input.GetKey (KeyCode.W)) {
				Cima ();
			}

			if (Input.GetKey (KeyCode.S)) {
				Baixo ();
			}
		} else {
			if (Input.GetKey (KeyCode.UpArrow)) {
				Cima ();
			}

			if (Input.GetKey (KeyCode.DownArrow)) {
				Baixo ();
			}
		}
	}
		
	void Cima(){
		rb.MovePosition (rb.position + new Vector2 (0, velocidadeY) * Time.deltaTime);
	}

	void Baixo(){
		rb.MovePosition (rb.position + new Vector2(0, -velocidadeY) * Time.deltaTime);
	}
}
