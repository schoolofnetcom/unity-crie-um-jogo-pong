﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class BolaController : MonoBehaviour {

	Rigidbody2D rb2d;
	[SerializeField]float velocidade;
	[SerializeField]Text PontosPlayer1TXT;
	[SerializeField]Text PontosPlayer2TXT;
	int player1Pts = 0;
	int	player2Pts = 0;
	// Use this for initialization
	void Start () {
		rb2d = GetComponent<Rigidbody2D> ();
		Invoke ("VaiBola",2);
	}

	void VaiBola(){
		float aleatorio = Random.Range (0, 2);

		if (aleatorio < 1) {
			rb2d.AddForce (new Vector2 (velocidade, -15));
		} else {
			rb2d.AddForce (new Vector2 (-velocidade, -15));
		}
	}

	void Textos(){
		PontosPlayer1TXT.text = player1Pts.ToString();
		PontosPlayer2TXT.text = player2Pts.ToString();
	}
		
	void OnTriggerEnter2D(Collider2D gol){
		if(gol.gameObject.name == "GolPlayer1"){
			player2Pts += 1;
			Debug.Log (player2Pts);
			Invoke ("ReiniciarJogo", 2);
		}

		if (gol.gameObject.name == "GolPlayer2") {
			player1Pts += 1;
			Debug.Log (player1Pts);
			Invoke ("ReiniciarJogo", 2);
		}
	}

	void ResetarBola(){
		rb2d.velocity = Vector2.zero;
		transform.position = Vector2.zero;
	}

	void ReiniciarJogo(){
		ResetarBola ();
		Invoke ("VaiBola",2);
	}


	public void Restart(){
		SceneManager.LoadScene ("main");
	}

	// Update is called once per frame
	void Update () {
		Textos ();
	}
}
